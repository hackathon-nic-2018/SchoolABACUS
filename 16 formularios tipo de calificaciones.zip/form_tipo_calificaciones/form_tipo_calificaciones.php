<?php 
  include_once('../form_tipo_calificaciones/index.php'); 
?> 
